<?php
namespace App\Http\Controllers;
use App\Mail\feedbackemail;
use Illuminate\Http\Request;
use \Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Mail;

class FeedbackController extends Controller {
    public function insertform(){
        return view('ContactUs2');
    }
    
    public function insert(Request $request){
        $con = mysqli_connect('localhost', 'id16449621_database', 'Q9~xtj3kuyG|aug7','id16449621_data');
        
        $nama =  mysqli_real_escape_string($con,$_POST['nama']);
        $feedback = mysqli_real_escape_string($con,$_POST['feedback']);
        $sql = "INSERT INTO Feedback (nama, masukan) VALUES ('$nama', '$feedback')";
        
        $rs = mysqli_query($con, $sql);
        
        $email = 'gregoriousjuann@gmail.com';
   
        $data = [
            'nama' => $nama,
            'feedback' => $feedback
        ];
  
        Mail::to("gregoriousjuann@gmail.com")->send(new feedbackemail($data));
        
        if($rs)
        {
        	 return redirect('ContactUs2');
        }
    }
}