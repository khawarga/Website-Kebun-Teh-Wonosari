<h3>Dari {{ $data['nama'] }}</h3>
<p>Masukan</p>
 
<p>{{ $data['feedback'] }}</a></p>