<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ContactUs</title>

<style>
* {
  box-sizing: border-box;
}
		
body {
  font-family: Arial;
  background: #FFFFFF;
	margin: 0px;
}
		
.back{
	background-image:url("{{ URL::asset('uploads/darjeelling darkened.jpg') }}");
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 50px;
}
		
.header {
    padding: 20px;
	padding-bottom: 50px;
}

.header h1 {
    font-size: 25px;
	text-align: left;
	color: #D1D011;
}
		
.header h3{
	color: aliceblue;
	text-align: left;
}

/* Style the top navigation bar */
.topnav {
   overflow: hidden;
}

/* Style the topnav links */
.topnav a {
  display: block;
  color: aliceblue;
  font-weight: bold;
  padding: 5px 17px;
  text-decoration:none;
  text-align: center;
  float: left;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

section{
  display: -webkit-flex;
  			display: flex;
}
.middle{
  padding: 10px;
}
.middle a{
  			text-decoration:none;
}
.right{
  width: 45%;
  float: left;
  padding: 10px;
  margin-left: 100px;
}

.left{
  margin-left: 100px;
  width: 35%;
  float: left;
  padding: 30px;
}
input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

textarea, select {
  width: 60%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  
}
input[type=submit] {
  width: 30%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=submit]:hover {
  background-color: #45a049;
}

footer {
			padding: 40px;
			padding-bottom: 100px;
  			text-align: center;
  			background-image: url("{{ URL::asset('uploads/Hut darkened.jpg') }}");
			margin-top: 0px;
}
}

    @media (max-width: 600px) {
  section {
   			-webkit-flex-direction: column;
    		flex-direction: column;
  			}
        footer {
   			-webkit-flex-direction: column;
    		flex-direction: column;
  			}
    }
</style>
</head>

<body>
    <div class="back">
        <div class="topnav">
        <a href="Home">Home</a>
        <a href="AboutUs">About Us</a>
        <a href="streeview_doang_sampe_1_page">Streetview</a>
        <a href="login">Login</a>
        </div>
        <div class="header">
            <h1>Contact Us</h1>
        </div>
    </div>	
  <div class="middle">
    <section>
      <address>
        <div class="left">
          <a>Email &nbsp;&nbsp;: wonosari@agro-ptpn12.com</a><br><br>
          <a>Phone : +623415425754</a><br><br>
          <a>Phone : +628113637198</a>
        </div>
        <div class="right">
          <p>Alamat : Kebun Teh Wonosari, RT.04/RW.07, Bodean Putuk, Toyomarto
          Singosari, Malang, East Java 65153</p>
          <a>Twitter : @WAWonosari</a><br><br>
          <a>Instagram : wisataagrowonosari</a>
        </div>
      </address>
    </section>
  </div>
    

    <footer>
      <h3 style="color: yellow;">We Value Your Feedback</h3>
            <form action="create2" method="post" style="text-align: center;">
                {{ csrf_field() }}
                <label for="nama" style="color: white;">Name: </label><br><br>
                <input type="text" id="nama" name="nama" placeholder="Your name..." required><br><br>
                <label for="feedback" style="color: white;">Feedback: </label><br><br>
                <textarea id="feedback" name="feedback" rows="6" cols="60" placeholder="Maksimal 255 karakter" required></textarea><br><br>
                <input type="submit" value="Send Feedback">
            </form>
            <center><h2><font color=white>Terima kasih atas feedback anda</font></h2></center>
        </div>
    </footer>

</body>