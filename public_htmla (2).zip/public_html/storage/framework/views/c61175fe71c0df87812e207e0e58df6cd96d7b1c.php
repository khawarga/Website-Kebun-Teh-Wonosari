<h3>Dari <?php echo e($data['nama']); ?></h3>
<p>Masukan</p>
 
<p><?php echo e($data['feedback']); ?></a></p><?php /**PATH /storage/ssd3/621/16449621/public_html/resources/views/feedbackemail.blade.php ENDPATH**/ ?>