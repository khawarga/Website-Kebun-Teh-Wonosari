<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reservation</title>

<style>
* {
  box-sizing: border-box;
}
		
body {
  font-family: Arial;
  background: #FFFFFF;
	margin: 0px;
}
		
.back{
	background-image:url("<?php echo e(URL::asset('uploads/darjeelling darkened.jpg')); ?>");
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 50px;
}
		
.header {
    padding: 20px;
	padding-bottom: 50px;
}

.header h1 {
    font-size: 25px;
	text-align: left;
	color: #D1D011;
}
		
.header h3{
	color: aliceblue;
	text-align: left;
}

/* Style the top navigation bar */
.topnav {
   overflow: hidden;
}

/* Style the topnav links */
.topnav a {
  display: block;
  color: aliceblue;
  font-weight: bold;
  padding: 5px 17px;
  text-decoration:none;
  text-align: center;
  float: left;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

input[type=text], select {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=date], select {
  width: 15%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=number], select {
  width: 6%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 10%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-left:150px;
}
input[type=submit]:hover {
  background-color: #45a049;
}
    footer {
      display:absolute;
		padding: 40px;
  		text-align: center;
  		background-image: url("<?php echo e(URL::asset('uploads/darjeelling darkened.jpg')); ?>");
		margin-top: 0px;
        height:210px;
		}
    footer h1{
      font-size: large;
      text-align: center;
      color: #D1D011;
    }
		footer a{
			display: block;
  			color:aliceblue;
  			font-weight: bold;
  			padding: 5px 17px;
  			text-decoration:none;
  			text-align: center;
		}

    .input{
        padding: 50px;
    }

    .input:after{
      content: "";
      display: table;
      clear: both;
    }

    .spasi{
      display:none;
    }

    @media (max-width: 800px) {
      input[type=number]{
        width:20%;
      }

      input[type=date]{
        width:50%;
      }

      input[type=text]{
        width:70%;
      }
    }

</style>
</head>
<body>
    <div class="back">
        <div class="topnav">
        <a href="HomeV2">Home</a>
        <a href="ReservationV2">Reservation</a>
        <a href="AboutUsV2">About Us</a>
        <a href="streeview_doang_sampe_1_pageV2">Streetview</a>
        <a>Hallo, <?php echo e(Auth::user()->name); ?> </a>
        <a href="logout">Logout</a>
        </div>
        <div class="header">
            <h1>Reservation</h1>
            <font color=white><p id="TRIVIA"></p></font>
        </div>
    </div>	
    
    <div class="input">
      <form action="create" method="post">
         <?php echo e(csrf_field()); ?>

        <label for="nama">Nama:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="text" id="nama" name="nama" placeholder="Your name..." required><br>
        <label for="">Tanggal Check In: </label>
        <input type="date" id="tanggal" name="tanggal" value="<?php echo e(old('expiry_date')); ?>" required> <br>
        <label for="number">Jumlah orang:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="number" id="jumlah" name="jumlah" required>
        <input type="submit" value="Submit">
        <center><h2>Kami tunggu kedatangan anda</h2></center>
      </form>
    </div>
    
    <script>
        var gacha = Math.floor((Math.random()*53)+1)
        var tips;
        switch(gacha){
            case 1 :
                tips = "Teh merupakan minuman kedua yang paling banyak diminum setelah air";
                break;
            case 2 :
                tips = "Teh dibuat menggunakan daun dari tanaman Camellia Sinensis yang dimana tanaman tersebut memiliki berbagai variasi";
                break;
			case 3 :
                tips = "Bila tidak mengandung Camellia Sinensis maka itu bukan teh melainkan Tisane";
                break;
			case 4 :
                tips = "Daun dari tumbuhan raspberry dapat dibuat menjadi teh herbal";
                break;
			case 5 :
                tips = "3 juta ton teh dibuat setiap tahunnya di seluruh dunia";
                break;
			case 6 :
                tips = "Ada 4jenis teh yang umum yaitu black, white, green, dan oolong";
                break;		
			case 7 :
                tips = "Di US terdapat lebih dari 1.42 juta pon teh yang dikonsumsi setiap hari";
                break;
			case 8 :
                tips = "Terdapat sekitar 1500 jenis teh yang diketahui di dunia namun jumlah pastinya masih belum diketahui";
                break;
			case 9 :
                tips = "Butuh 3 tahun sebelum teh dapat dipanen dari tumbuhan baru dan membutuhkan 4 sampai 12 tahun untuk menghasilkan benih";
                break;
			case 10 :
                tips = "Teh menyerap kelembapan sehingga harus disimpan dengan baik";
                break;
			case 11 :
                tips = "Teh hitam dalam proses pembuatannya teroksidasi paling banyak sedangkan teh putih teroksidasi paling sedikit";
                break;
			case 12 :
                tips = "Teh ditemukan pada tahun 2737 sebelum masehi. Kaisar Shennong meminum air panas yang kejatuhan daun teh";
                break;
			case 13:
				tips = "The Dutch East India Company memperkenalkan teh ke barat yang awalnya disebut dengan Tay / Cha yang kemudian berubah menjadi tea";
				break;
			case 14 :
                tips = "Pada tahun 1700 penyelundup menghasilkan keuntungan dari teh dengan menambahkan daun kering.";
                break;
			case 15 :
                tips = "Awal pembuatan teh menggunakan susu agar tidak memecahkan cangkir China dengan panasnya";
                break;
			case 16 :
                tips = "Teh merupakan peringkat ke 31 tanaman/hewan ternak paling berharga dan teh menghasilkan $5.5 trilliun dollar per tahun";
                break;
			case 17 :
                tips = "Dipercaya bahwa teh hijau paling baik dihasilkan dengan panen pertama setiap tahun yaitu april sampai pertengahan mei";
                break;
			case 18 :
                tips = "Resep Es teh manis tertua secara tertulis berasal dari kumpulan buku resep berjudul Houskeeping of Old Virginia karya Marion Cable Tyree yang dipublikasikan pada 1879";
                break;
			case 19 :
                tips = "Daun teh yang dipetik hanyalah 1 - 2 inch dari atas";
                break;
			case 20 :
                tips = "Daun teh tidak boleh direbus lebih dari 2 kali karena bisa membuat teh menjadi hambar";
                break;
			case 21 :
                tips = "Karkade merupakan teh yang umum di mesir, dibuat dengan campuran bunga hibiscus dan gula";
                break;
			case 22 :
                tips = "Di beberapa tempat teh digunakan sebagai salah satu mata uang hingga abad ke 20";
                break;
			case 23 :
                tips = "Bajak laut sering membajak kapal yang mengangkut teh";
                break;
			case 24 :
                tips = "Tanaman yang menghasilkan teh biasanya berada di ketinggian 3000 sampai 7000 kaki diatas permukaan laut";
                break;
			case 25 :
                tips = "China, Taiwan, Jepang, India, Sri Lanka and Kenya merupakan negara penghasil teh terbanyak";
                break;
			case 26 :
                tips = "Awalnya root beer dipanggil dengan root tea";
                break;
			case 27 :
                tips = "Charles E. Hires mengalami kesusahan menjual root tea karena penduduk lokal yang merupakan penambang batu bara tidak biasa membeli teh sehingga namanya diubah menjadi root beer";
                break;
			case 28 :
                tips = "Teh yang umum di timur tengah adalah Moroccan Mint Tea";
                break;
			case 29 :
                tips = "Matcha tea merupakan teh hijau dari jepang yang berbentuk bubuk";
                break;
			case 30 :
                tips = "Buku pertama tentang teh dibuat pada tahun 780 yang ditulis oleh Lu Yu";
                break;
			case 31 :
                tips = "Pada abad ke 18, Inggris menetapkan pajak yang tinggi untuk teh sehingga marak terjadi penyelundupan teh";
                break;
			case 32 :
                tips = "Olive leaf tea merupakan teh dari italia";
                break;
			case 33 :
                tips = "Pada tahun 2016 peneliti menemukan teh tertua di kuburan Dinasti Han yang dikubur sekitar 141 sebelum masehi";
                break;
			case 34 :
                tips = "Teh diperkenalkan ke Inggris pada tahun 1679";
                break;
			case 35 :
                tips = "Teh hitam dapat disimpan hingga maksimal 2 tahun";
                break;
			case 36 :
                tips = "Bubble tea dibuat pada tahun 1980 di Taiwan";
                break;
			case 37 :
                tips = "The British Standard Institute mengeluarkan panduan untuk menyiapkan teh";
                break;
			case 38 :
                tips = "Teh merupakan sumber alami fluoride yang melawan kerusakan gigi dan penyakit gusi";
                break;
			case 39 :
                tips = "Oolong tea dapat direndam hingga 3 kali dan memiliki rasa yang berbeda setiap kali direndam";
                break;
			case 42 :
                tips = "Teh yang disajikan di pesawat memiliki rasa yang berbeda karena titik didihnya menjadi lebih rendah akibat dari tekanan udara";
                break;
			case 41 :
                tips = "Pada abad ke 19 teh sangat berharga hingga disimpan dengan berhati hati di dalam brangkas";
                break;
			case 40 :
                tips = "Teh menjadi populer pada abad ke 18";
                break;
			case 43 :
                tips = "Teh hijau dan teh oolong biasanya direndam selama 2 menit dan teh hitam biasanya direndam 3-5 menit.";
                break;
			case 44 :
                tips = "Teh memiliki antioksidan yang tinggi";
                break;
			case 45 :
                tips = "Chrysanthemum tea memiliki efek mengurangi sakit kepala dan demam";
                break;
			case 46 :
                tips = "Teh telah diminum selama lebih dari 3000 tahun";
                break;
			case 47 :
                tips = "85% teh di US diolah menjadi es teh manis ";
                break;
			case 48 :
                tips = "Pada tahun 1773 banyak teh yang dibuang sebagai bentuk protes terhadap pajak teh";
                break;
			case 49 :
                tips = "Teh merupakan minuman nasional dari Iran dan Afghanistan";
                break;
			case 50 :
                tips = "Daun teh hijau dan putih tidak di fermentasi, hanya dipanaskan untuk menghilangkan kelembaban";
                break;
			case 51 :
                tips = "Teh memiliki banyak keuntungan bagi kesehatan";
                break;
			case 52 :
                tips = "Pada tahun 1600 teh diperkenalkan ke Russia oleh China";
                break;
			case 53 :
				tips = "Minumlah teh setiap hari";
				break;
			}
        document.getElementById("TRIVIA").innerHTML = "Teh Tips : " + tips;
    </script>

    <footer>
      <br><br><br>
      <h1>Wonosari Tea Garden Welcomes You</h1>
      <p><a href="ContactUsV2">Contact Us</a></p>
    </footer>	
</body><?php /**PATH /storage/ssd3/621/16449621/public_html/resources/views/Reservation2_login.blade.php ENDPATH**/ ?>