<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('HOME V 2');
});

Route::get('/Home', function () {
    return view('HOME V 2');
});

Route::get('/AboutUs', function () {
    return view('AboutUs');
});

Route::get('/ContactUs', function () {
    return view('ContactUs');
});

Route::post('/create','ReservationController@insert');

Route::get('/ContactUs2', function () {
    return view('ContactUs2');
});

Route::get('/streeview_doang_sampe_1_page', function () {
    return view('streeview_doang_sampe_1_page');
});


//login

Route::get('/HomeV2', function () {
    return view('HOME V 2_login');
});

Route::get('/AboutUsV2', function () {
    return view('AboutUs_login');
});

Route::get('/ReservationV2', function () {
    return view('Reservation_login');
});

Route::get('/ContactUsV2', function () {
    return view('ContactUs_login');
});

Route::get('/Reservation2V2', function () {
    return view('Reservation2_login');
});

Route::get('/ContactUs2V2', function () {
    return view('ContactUs2_login');
});

Route::get('/streeview_doang_sampe_1_pageV2', function () {
    return view('streetview_doang_sampe_1_page_login');
});


//fungsi login
Route::get('/login', 'AuthController@showFormLogin')->name('login');
Route::get('login', 'AuthController@showFormLogin')->name('login');
Route::post('login', 'AuthController@login');
Route::get('register', 'AuthController@showFormRegister')->name('register');
Route::post('register', 'AuthController@register');

Route::get('/logout', 'AuthController@logout');