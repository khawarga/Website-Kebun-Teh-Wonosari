<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ReservationController extends Controller {
    public function insertform(){
        return view('Reservation');
    }
    
    public function insert(Request $request){
        $con = mysqli_connect('localhost', 'id16449621_database', 'Q9~xtj3kuyG|aug7','id16449621_data');
        
        $nama =  mysqli_real_escape_string($con,$_POST['nama']);
        $tanggal = mysqli_real_escape_string($con,$_POST['tanggal']);
        $jumlah = mysqli_real_escape_string($con,$_POST['jumlah']);
        $sql = "INSERT INTO Reservation (nama, tanggal, jumlah) VALUES ('$nama', '$tanggal', '$jumlah')";
        
        $rs = mysqli_query($con, $sql);

        if($rs)
        {
        	return redirect('/Reservation2');
        }
    }
}
