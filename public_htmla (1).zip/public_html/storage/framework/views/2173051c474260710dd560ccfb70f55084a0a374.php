<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>	
<style>
* {
  	box-sizing: border-box;
}
		
body {
	margin: 0px;
  	font-family: Arial;
  	background: #FFFFFF;
}
		
.back{
	background-image: url("<?php echo e(URL::asset('uploads/testimoni2.jpg')); ?>");
	text-align: right;
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 50px;
}
		
.header {
    padding: 20px;
}

.header h1 {
    font-size: 25px;
	text-align: right;
	color: #D1D011
}
		
.header h3{
	color: aliceblue;
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
}

/* Style the topnav links */
.topnav a {
  display: block;
  color: #000000;
  font-weight: bold;
  padding: 5px 17px;
  text-decoration:none;
  text-align: center;
  float: left;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}
		
.welcome{
	padding-bottom: 50px;
}
		
.welcome h2{
	font-size: 20px;
}
		
.welcome p{
			font-size: 15px;
}
		
.middle{
	background-image: url("<?php echo e(URL::asset('uploads/jalan jalan.jpg')); ?>") ;
	text-align: right;
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 150px;
}
		
		.middle h2{
			padding-top: 150px;
		}
		
		.cardhead{
			text-align: center;
		}
		
		.cardhead h2{
			color: aliceblue;
		}
		
		.card{
			padding: 10px;
			padding right: 100px;
			text-align: center;
			background:#FFFFFF;
			width: 20%;
			float: right;
			margin-left: 100px;
			margin-right: 100px;
		}
		
		.card img{
			width: 100%;
			height: auto;
		}

		.space{
			padding-bottom: 50px;
		}
		
		section {
			display: -webkit-flex;
  			display: flex;
			}
		
		.image{
			float:left;
			width: 50%;
		}
		
		.text{
			float: right;
			width: 100%;
			text-align: left;
			padding: 20px;
		}
		
		footer {
			padding: 20px;
			padding-bottom: 50px;
  			text-align: center;
  			background: #333;
		}
		
		@media (max-width: 800px) {
  			section {
   			-webkit-flex-direction: column;
    		flex-direction: column;
  			}
		}
		
		.image img {
			width: 100%;
  			height: auto;
		}
		
</style>	
</head>
	
<body>
<div class="back">
	<div class="topnav">
		<a href="">Reservation</a>
		<a href="">Home</a>
		<a href="">About Us</a>
	</div>
	
	<div class="header">
		<h1>Kebun Teh Wonosari</h1>
	  	<h3>test test</h3>
    </div>
</div>
	
<div class="welcome">
	<h2 style="text-align: center">TITLE</h2>
	<p style="text-align: center">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Aliquet nec ullamcorper sit amet risus. Enim nunc faucibus a pellentesque sit amet. Est ultricies integer quis auctor elit sed. Nunc eget lorem dolor sed viverra ipsum nunc aliquet. Egestas maecenas pharetra convallis posuere morbi leo urna. Euismod elementum nisi quis eleifend. Habitant morbi tristique senectus et netus et malesuada. Magna eget est lorem ipsum dolor sit. Orci porta non pulvinar neque. Ullamcorper morbi tincidunt ornare massa eget egestas purus viverra. Velit ut tortor pretium viverra. Urna et pharetra pharetra massa massa.</p>
</div>
	
<div class="middle">
	<div class="cardhead"><h3><br>Title<br><br></h3>
</div>
	<section>
		<div class="card">
			<h3>test</h3>
			<img src="<?php echo e(asset('gambar/Penginapan.jpg')); ?>" width="110" height="120" alt=""/>
		</div>
		<div class="card">
			<h3>test</h3>
			<img src="<?php echo e(asset('gambar/Penginapan.jpg')); ?>" width="110" height="120" alt=""/>
		</div>
		<div class="card">
			<h3>test</h3>
			<img src="<?php echo e(asset('gambar/Penginapan.jpg')); ?>" width="110" height="120" alt=""/>
		</div>
	</section>
	
	<h2 align="center"><button onClick="">More About Us</button></h2>
</div>
	
<div class="space"></div>
	
<section>
	<div class="image">
		<p><img src="<?php echo e(asset('gambar/playground.jpg')); ?>" width="330" height="160" alt=""/></p>
		<p><img src="<?php echo e(asset('gambar/testimoni1.jpg')); ?>" width="330" height="160" alt=""/></p>
	</div>	
	
	<div class="text">
  		<h2>title</h2>
		<p style="text-align: left">Welcome to The Garden of Dreams
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Aliquet nec ullamcorper sit amet risus. Enim nunc faucibus a pellentesque sit amet. Est ultricies integer quis auctor elit sed. Nunc eget lorem dolor sed viverra ipsum nunc aliquet. Egestas maecenas pharetra convallis posuere morbi leo urna. Euismod elementum nisi quis eleifend. Habitant morbi tristique senectus et netus et malesuada. Magna eget est lorem ipsum dolor sit. Orci porta non pulvinar neque. Ullamcorper morbi tincidunt ornare massa eget egestas purus viverra. Velit ut tortor pretium viverra. Urna et pharetra pharetra massa massa.
		</p>
	</div>
</section>

<footer>
	<p><button onClick="">Reserve now</button></p>
</footer>
	
</body>
</html>
<?php /**PATH D:\KULIAH\Human and Computer Interaction\PROYEK\blog\resources\views/HOME V 2.blade.php ENDPATH**/ ?>