<!doctype html>
<html>
<head>
<meta charset="utf-8" content="width=device-width, initial-scale=1.0">
<title>HOME</title>	
<style>
* {
  	box-sizing: border-box;
}
		
body {
	margin: 0px;
  	font-family: Arial;
  	background: #FFFFFF;
}
		
.back{
	background-image: url("<?php echo e(URL::asset('uploads/Kebun-Teh Blackened.jpg')); ?>");
	text-align: right;
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 50px;
}
		
.header {
    padding: 20px;
}

.header h1 {
    font-size: 50px;
	text-align: right;
	color: #D1D011
}
		
.header h3{
	color: aliceblue;
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
}

/* Style the topnav links */
.topnav a {
  display: block;
  color: #ddd;
  font-weight: bold;
  padding: 5px 17px;
  text-decoration:none;
  text-align: center;
  float: right;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}
		
.welcome{
	padding-bottom: 50px;
	margin-left: 50px;
	margin-right: 50px;
}
		
.welcome h2{
	font-size: 40px;
}
		
.welcome p{
			font-size: 15px;
}
		
.middle{
	background-image: url("<?php echo e(URL::asset('uploads/Hut darkened.jpg')); ?>") ;
	text-align: right;
	background-repeat: no-repeat;
	background-size: cover;
	padding-bottom: 150px;
}
		
		.middle h2{
			padding-top: 150px;
		}
		
		.cardhead{
			text-align: center;
		}
		
		.cardhead h3{
			color: aliceblue;
		}
		
        .card{
            background: hsla(119, 22%, 81%, 0.3);
            margin-left:150px;
            border-radius: 40px;
            padding: 10px;
        }
	
		.card-img-top{
			width: 100%;
			height: 70%;
		}
		
		.card-text{
			color:aliceblue;
			margin-right:35%;
		}

		.space{
			padding-bottom: 50px;
		}
		
		section {
  			display: flex;
		}
		
		.card:hover{
			-ms-transform: scale(1.2); /* IE 9 */
			-webkit-transform: scale(1.2); /* Safari 3-8 */
			transform: scale(1.2); 
		}
		
		.image{
			float:left;
			width: 50%;
			margin-left: 25px;
		}
		
		.text{
			float: right;
			width: 100%;
			text-align: left;
			padding: 20px;
			margin-right: 50px;
			margin-left: 50px;
		}
		
		footer {
			padding: 20px;
			padding-bottom: 50px;
  			text-align: center;
  			background: #333;
		}
		
		@media (max-width: 1000px) {
  			section {
   			-webkit-flex-direction: column;
    		flex-direction: column;
  			}
  			.card{
				width: 80%;
				margin-left: 250px;
				margin-bottom:20px;
				height:50%;
			}
			
			.card-img-top{
			    height: 300px;
		    }
		    
    		.topnav a{
    		    float: none;
    		}
		}
		
		@media (max-width: 600px) {
  			section {
   			-webkit-flex-direction: column;
    		flex-direction: column;
  			}
  			.card{
				margin-left: 50px;
			}
		}
		
		.image img {
			width: 500px;
  			height: auto;
		}

		.button1 {
		background-color: #4CAF50;
		border: none;
		border-radius: 30px;
		color: white;
		padding: 20px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
		
		}

		.button2 {
		background-color: #4CAF50;
		border-radius: 30px;
		border: none;
		color: white;
		padding: 20px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
		}
		
</style>	
</head>
	
<body>
<div class="back">
	<div class="topnav">
		<a href="HomeV2">Home</a>
		<a href="ReservationV2">Reservation</a>
		<a href="AboutUsV2">About Us</a>
		<a href="streeview_doang_sampe_1_pageV2">Streetview</a>
	    <a>Hallo, <?php echo e(Auth::user()->name); ?> </a>
        <a href="logout">Logout</a>
	</div>
	
	<div class="header">
		<h1>Kebun Teh Wonosari</h1>
	  	<h3>The Tea Garden of Dreams</h3>
		  <font color=white><p id="TRIVIA"></p></font>
    </div>
</div>
	
<div class="welcome">
	<h2 style="text-align: center">Welcome to The Garden of Dreams</h2>
	<p style="text-align: center">Agrowisata Kebun Teh Wonosari terletak di kaki gunung Arjuna, perbatasan wilayah antara kota Malang dan Surabaya, tepatnya di Desa Toyomarto, Kecamatan Singosari, Kabupaten Malang. Agrowisata Kebun Teh Wonosari merupakan sebuah proyek dari PTPN XII dimana PTPN XII menangani perluasaan produksi teh dan juga penyalurannya dengan produk yang dipasarkan adalah teh celup. Jadi di Agrowisata Kebun Teh Wonosari Anda juga bisa menyaksikan langsung ketika panen teh dilakukan, kita juga bisa melihat cara meremajakan pohon teh, memproduksi teh, sampai dengan cara penyajiannya.</p>
</div>
	
<div class="middle">
	<div class="cardhead"><h3><br>Our Facilities<br><br></h3>
</div>
	<section>
    		<div class="card" style="width: 18rem;">
    		    <div class="card-body">
                    <p class="card-text">Penginapan</p>
                </div>
            <img class="card-img-top" src="<?php echo e(asset('gambar/Penginapan.jpg')); ?>" alt="Card image cap" >
        </div>
		<div class="card" style="width: 18rem;">
    		    <div class="card-body">
                    <p class="card-text">Jalan Jalan</p>
                </div>
            <img class="card-img-top" src="<?php echo e(asset('gambar/jalan jalan.jpg')); ?>" alt="Card image cap" >
        </div>
		<div class="card" style="width: 18rem;">
    		    <div class="card-body">
                    <p class="card-text">Playground</p>
                </div>
            <img class="card-img-top" src="<?php echo e(asset('gambar/play-ground.jpg')); ?>" alt="Card image cap" >
        </div>
	</section>
	
	<h2 align="center"><button class="button1" onclick="window.location.href ='AboutUs';">More About Us</button></h2>
</div>
	
<div class="space"></div>
	
<section>
	<div class="image">
		<p><img src="<?php echo e(asset('gambar/testimoni2.jpg')); ?>" width="330" height="160" alt=""/></p>
		<p><img src="<?php echo e(asset('gambar/testimoni1.jpg')); ?>" width="330" height="160" alt=""/></p>
	</div>	
	
	<div class="text">
  		<h1>Welcome to The Garden of Dreams</h1>
		<h3><font color=green>Sebuah pertumbuhan, tak hanya perjalanan</font></h3>
		<p style="text-align: justify">
		Di Agrowisata Kebun Teh Wonosari Anda bisa menyaksikan langsung ketika panen teh dilakukan, kita juga bisa melihat cara meremajakan pohon teh, memproduksi teh, sampai dengan cara penyajiannya. Agrowisata Kebun Teh Wonosari juga memiliki fasilitas olahraga yang bisa anda nikmati seperti sepak bola, tenis, bola volly, serta joging. Selain itu di Agrowisata Kebun Teh Wonosari juga memiliki koleksi hewan yang dapat Anda nikmati. Jika Anda ingin berenang, Agrowisata Kebun Teh Wonosari juga memiliki fasilitas kolam renang dengan air yang hangat.<br><br>
		Anda dapat menyewa sebuah villa jika berwisata dengan banyak orang ataupun menyewa hotel jika anda datang sendiri atau dengan keluarga.	
		</p>
	</div>
</section>

<script>
        var gacha = Math.floor((Math.random()*53)+1)
        var tips;
        switch(gacha){
            case 1 :
                tips = "Teh merupakan minuman kedua yang paling banyak diminum setelah air";
                break;
            case 2 :
                tips = "Teh dibuat menggunakan daun dari tanaman Camellia Sinensis yang dimana tanaman tersebut memiliki berbagai variasi";
                break;
			case 3 :
                tips = "Bila tidak mengandung Camellia Sinensis maka itu bukan teh melainkan Tisane";
                break;
			case 4 :
                tips = "Daun dari tumbuhan raspberry dapat dibuat menjadi teh herbal";
                break;
			case 5 :
                tips = "3 juta ton teh dibuat setiap tahunnya di seluruh dunia";
                break;
			case 6 :
                tips = "Ada 4jenis teh yang umum yaitu black, white, green, dan oolong";
                break;		
			case 7 :
                tips = "Di US terdapat lebih dari 1.42 juta pon teh yang dikonsumsi setiap hari";
                break;
			case 8 :
                tips = "Terdapat sekitar 1500 jenis teh yang diketahui di dunia namun jumlah pastinya masih belum diketahui";
                break;
			case 9 :
                tips = "Butuh 3 tahun sebelum teh dapat dipanen dari tumbuhan baru dan membutuhkan 4 sampai 12 tahun untuk menghasilkan benih";
                break;
			case 10 :
                tips = "Teh menyerap kelembapan sehingga harus disimpan dengan baik";
                break;
			case 11 :
                tips = "Teh hitam dalam proses pembuatannya teroksidasi paling banyak sedangkan teh putih teroksidasi paling sedikit";
                break;
			case 12 :
                tips = "Teh ditemukan pada tahun 2737 sebelum masehi. Kaisar Shennong meminum air panas yang kejatuhan daun teh";
                break;
			case 13:
				tips = "The Dutch East India Company memperkenalkan teh ke barat yang awalnya disebut dengan Tay / Cha yang kemudian berubah menjadi tea";
				break;
			case 14 :
                tips = "Pada tahun 1700 penyelundup menghasilkan keuntungan dari teh dengan menambahkan daun kering.";
                break;
			case 15 :
                tips = "Awal pembuatan teh menggunakan susu agar tidak memecahkan cangkir China dengan panasnya";
                break;
			case 16 :
                tips = "Teh merupakan peringkat ke 31 tanaman/hewan ternak paling berharga dan teh menghasilkan $5.5 trilliun dollar per tahun";
                break;
			case 17 :
                tips = "Dipercaya bahwa teh hijau paling baik dihasilkan dengan panen pertama setiap tahun yaitu april sampai pertengahan mei";
                break;
			case 18 :
                tips = "Resep Es teh manis tertua secara tertulis berasal dari kumpulan buku resep berjudul Houskeeping of Old Virginia karya Marion Cable Tyree yang dipublikasikan pada 1879";
                break;
			case 19 :
                tips = "Daun teh yang dipetik hanyalah 1 - 2 inch dari atas";
                break;
			case 20 :
                tips = "Daun teh tidak boleh direbus lebih dari 2 kali karena bisa membuat teh menjadi hambar";
                break;
			case 21 :
                tips = "Karkade merupakan teh yang umum di mesir, dibuat dengan campuran bunga hibiscus dan gula";
                break;
			case 22 :
                tips = "Di beberapa tempat teh digunakan sebagai salah satu mata uang hingga abad ke 20";
                break;
			case 23 :
                tips = "Bajak laut sering membajak kapal yang mengangkut teh";
                break;
			case 24 :
                tips = "Tanaman yang menghasilkan teh biasanya berada di ketinggian 3000 sampai 7000 kaki diatas permukaan laut";
                break;
			case 25 :
                tips = "China, Taiwan, Jepang, India, Sri Lanka and Kenya merupakan negara penghasil teh terbanyak";
                break;
			case 26 :
                tips = "Awalnya root beer dipanggil dengan root tea";
                break;
			case 27 :
                tips = "Charles E. Hires mengalami kesusahan menjual root tea karena penduduk lokal yang merupakan penambang batu bara tidak biasa membeli teh sehingga namanya diubah menjadi root beer";
                break;
			case 28 :
                tips = "Teh yang umum di timur tengah adalah Moroccan Mint Tea";
                break;
			case 29 :
                tips = "Matcha tea merupakan teh hijau dari jepang yang berbentuk bubuk";
                break;
			case 30 :
                tips = "Buku pertama tentang teh dibuat pada tahun 780 yang ditulis oleh Lu Yu";
                break;
			case 31 :
                tips = "Pada abad ke 18, Inggris menetapkan pajak yang tinggi untuk teh sehingga marak terjadi penyelundupan teh";
                break;
			case 32 :
                tips = "Olive leaf tea merupakan teh dari italia";
                break;
			case 33 :
                tips = "Pada tahun 2016 peneliti menemukan teh tertua di kuburan Dinasti Han yang dikubur sekitar 141 sebelum masehi";
                break;
			case 34 :
                tips = "Teh diperkenalkan ke Inggris pada tahun 1679";
                break;
			case 35 :
                tips = "Teh hitam dapat disimpan hingga maksimal 2 tahun";
                break;
			case 36 :
                tips = "Bubble tea dibuat pada tahun 1980 di Taiwan";
                break;
			case 37 :
                tips = "The British Standard Institute mengeluarkan panduan untuk menyiapkan teh";
                break;
			case 38 :
                tips = "Teh merupakan sumber alami fluoride yang melawan kerusakan gigi dan penyakit gusi";
                break;
			case 39 :
                tips = "Oolong tea dapat direndam hingga 3 kali dan memiliki rasa yang berbeda setiap kali direndam";
                break;
			case 42 :
                tips = "Teh yang disajikan di pesawat memiliki rasa yang berbeda karena titik didihnya menjadi lebih rendah akibat dari tekanan udara";
                break;
			case 41 :
                tips = "Pada abad ke 19 teh sangat berharga hingga disimpan dengan berhati hati di dalam brangkas";
                break;
			case 40 :
                tips = "Teh menjadi populer pada abad ke 18";
                break;
			case 43 :
                tips = "Teh hijau dan teh oolong biasanya direndam selama 2 menit dan teh hitam biasanya direndam 3-5 menit.";
                break;
			case 44 :
                tips = "Teh memiliki antioksidan yang tinggi";
                break;
			case 45 :
                tips = "Chrysanthemum tea memiliki efek mengurangi sakit kepala dan demam";
                break;
			case 46 :
                tips = "Teh telah diminum selama lebih dari 3000 tahun";
                break;
			case 47 :
                tips = "85% teh di US diolah menjadi es teh manis ";
                break;
			case 48 :
                tips = "Pada tahun 1773 banyak teh yang dibuang sebagai bentuk protes terhadap pajak teh";
                break;
			case 49 :
                tips = "Teh merupakan minuman nasional dari Iran dan Afghanistan";
                break;
			case 50 :
                tips = "Daun teh hijau dan putih tidak di fermentasi, hanya dipanaskan untuk menghilangkan kelembaban";
                break;
			case 51 :
                tips = "Teh memiliki banyak keuntungan bagi kesehatan";
                break;
			case 52 :
                tips = "Pada tahun 1600 teh diperkenalkan ke Russia oleh China";
                break;
			case 53 :
				tips = "Minumlah teh setiap hari";
				break;
			}
        document.getElementById("TRIVIA").innerHTML = "Teh Tips : " + tips;
    </script>

<footer>
	<p><button class="button2" id="reserve" onClick="window.location.href ='ContactUs';">Contact Us</button></p>
</footer>
</body>
</html>
<?php /**PATH /storage/ssd3/621/16449621/public_html/resources/views/HOME V 2_login.blade.php ENDPATH**/ ?>